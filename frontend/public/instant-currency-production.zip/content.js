(function () {
  const SYMBOL_TO_CODE = {
    "$": "USD", "US$": "USD", "C$": "CAD", "CA$": "CAD", "A$": "AUD", "AU$": "AUD",
    "NZ$": "NZD", "HK$": "HKD", "S$": "SGD", "€": "EUR", "£": "GBP", "¥": "JPY",
    "₹": "INR", "₽": "RUB", "₩": "KRW", "₺": "TRY", "₪": "ILS", "₫": "VND",
    "฿": "THB", "R$": "BRL", "CHF": "CHF",
  };
  const CODES = ["USD", "EUR", "GBP", "INR", "JPY", "CNY", "AUD", "CAD", "CHF", "NZD", "SGD", "HKD", "SEK", "NOK", "DKK", "KRW", "MXN", "BRL", "ZAR", "TRY", "RUB", "AED", "SAR", "THB", "IDR", "MYR", "PHP", "PLN", "CZK", "HUF", "ILS", "VND", "TWD"];
  const SUFFIX_MULTIPLIERS = { K: 1e3, M: 1e6, B: 1e9, T: 1e12 };
  const STALE_AFTER_MS = 12 * 60 * 60 * 1000; // 12 hours — matches background alarm refresh
  const FREE_CONVERSION_LIMIT = 49;
  const CONFIG = globalThis.INSTANT_CURRENCY_CONFIG || {};
  // API_BASE_URL is set by config.js (injected at build time).
  // If config.js is missing or empty, we intentionally leave it blank so
  // IS_DEV stays false and no accidental localhost traffic occurs in production.
  const API_BASE_URL = (CONFIG.API_BASE_URL || "").replace(/\/$/, "");
  const IS_DEV = CONFIG.ENV === "development" || (API_BASE_URL && (API_BASE_URL.includes("localhost") || API_BASE_URL.includes("127.0.0.1")));

  // Automatically inject extension ID into webpage's localStorage for seamless sync
  const ACCOUNT_ORIGIN = CONFIG.ACCOUNT_ORIGIN || (CONFIG.ACCOUNT_URL ? new URL(CONFIG.ACCOUNT_URL).origin : "");
  const currentOrigin = window.location.origin;
  const isAllowedHost = currentOrigin === ACCOUNT_ORIGIN ||
                        (IS_DEV && (currentOrigin.startsWith("http://localhost:") || currentOrigin.startsWith("http://127.0.0.1:")));

  if (isAllowedHost) {
    try {
      const script = document.createElement("script");
      script.textContent = `
        try {
          localStorage.setItem('hc_extension_id', '${chrome.runtime.id}');
          window.dispatchEvent(new CustomEvent('HC_EXTENSION_READY', { detail: '${chrome.runtime.id}' }));
        } catch (e) {
          console.error('[HoverConvert] Failed to set extension ID:', e);
        }
      `;
      (document.head || document.documentElement).appendChild(script);
      script.remove();
    } catch (e) {
      console.error("[HoverConvert] Failed to inject extension ID:", e);
    }
  }

  const NAME_TO_CODE = {
    "dollar": "USD", "dollars": "USD",
    "euro": "EUR", "euros": "EUR",
    "pound": "GBP", "pounds": "GBP",
    "rupee": "INR", "rupees": "INR",
    "yen": "JPY", "yens": "JPY",
    "yuan": "CNY", "yuans": "CNY",
    "franc": "CHF", "francs": "CHF",
    "real": "BRL", "reais": "BRL",
    "lira": "TRY", "liras": "TRY",
    "shekel": "ILS", "shekels": "ILS",
    "dong": "VND", "dongs": "VND",
    "baht": "THB", "bahts": "THB",
    "ruble": "RUB", "rubles": "RUB",
    "won": "KRW", "wons": "KRW"
  };

  const NAMES = Object.keys(NAME_TO_CODE).sort((a, b) => b.length - a.length);
  const symbolKeys = Object.keys(SYMBOL_TO_CODE)
    .sort((a, b) => b.length - a.length)
    .map((s) => s.replace(/[$^.|?*+()[\]{}\\]/g, "\\$&"));
  const tokenPart = `${symbolKeys.join("|")}|${CODES.join("|")}|${NAMES.join("|")}`;
  const amountPart = "[+-]?\\d[\\d,.]*(?:[kKmMbBtT])?";
  const RE = new RegExp(`([+-]?)\\s*(?:(?:(${tokenPart})\\s*(${amountPart}))|(?:(${amountPart})\\s*(${tokenPart})))`, "i");
  // Pre-compiled token scanner — avoids recompiling a 500-char regex on every mouseup
  const RE_TOKEN = new RegExp(`(?:${tokenPart})`, "gi");

  let settingsCache = {};
  let tooltip = null;

  const settingsLoadedPromise = new Promise((resolve) => {
    chrome.storage.local.get(null, (settings) => {
      settingsCache = settings || {};
      // Sensible defaults if not initialized yet
      if (!settingsCache.targetCurrency) settingsCache.targetCurrency = "INR";
      if (!settingsCache.baseCurrency) settingsCache.baseCurrency = "USD";
      if (!settingsCache.rates) {
        settingsCache.rates = {
          "USD": 1,
          "INR": 83.5,
          "EUR": 0.92,
          "GBP": 0.78
        };
      }
      if (settingsCache.pageTooltipEnabled === undefined) settingsCache.pageTooltipEnabled = true;
      if (settingsCache.conversionsUsed === undefined) settingsCache.conversionsUsed = 0;
      resolve(settingsCache);
    });
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    for (const [key, change] of Object.entries(changes)) {
      if (change.newValue === undefined) delete settingsCache[key];
      else settingsCache[key] = change.newValue;
    }
  });

  function isContextValid() {
    try {
      return typeof chrome !== "undefined" && typeof chrome.runtime !== "undefined" && !!chrome.runtime.id;
    } catch {
      return false;
    }
  }

  function normalizeAmount(raw) {
    let trimmed = raw.trim();
    const hasPlus = trimmed.startsWith("+");
    if (hasPlus) {
      trimmed = trimmed.slice(1);
    }
    const suffixMatch = trimmed.match(/[kKmMbBtT]$/);
    const multiplier = suffixMatch ? SUFFIX_MULTIPLIERS[suffixMatch[0].toUpperCase()] : 1;
    let s = suffixMatch ? trimmed.slice(0, -1) : trimmed;
    s = s.replace(/\s/g, "");

    const lastComma = s.lastIndexOf(",");
    const lastDot = s.lastIndexOf(".");

    if (lastComma !== -1 && lastDot !== -1) {
      if (lastComma > lastDot) {
        s = s.replace(/\./g, "").replace(",", ".");
      } else {
        s = s.replace(/,/g, "");
      }
    } else if (lastComma !== -1) {
      const parts = s.split(",");
      const hasIndianGrouping = parts.length > 2 && parts.slice(1, -1).some((part) => part.length === 2);
      if (hasIndianGrouping || parts[parts.length - 1].length === 3) {
        s = s.replace(/,/g, "");
      } else {
        s = s.replace(",", ".");
      }
    }

    const amount = Number(s);
    return Number.isFinite(amount) ? amount * multiplier : NaN;
  }

  function detect(text) {
    if (!text || text.length > 200) return null;
    const m = RE.exec(text.trim());
    if (!m) return null;

    const sign = m[1] || "";
    const token = m[2] || m[5];
    const amountStr = m[3] || m[4];
    const upper = token.toUpperCase();
    const lower = token.toLowerCase();
    const code = SYMBOL_TO_CODE[token] || NAME_TO_CODE[lower] || (CODES.includes(upper) ? upper : null);
    if (!code) return null;

    let amount = normalizeAmount(amountStr);
    if (!Number.isFinite(amount)) return null;

    if (sign === "-") {
      amount = -Math.abs(amount);
    }
    return { code, amount };
  }

  /**
   * Given a selection range, extract a context window of ~40 chars before
   * and after the selected text from the surrounding DOM ancestor.
   * This handles cases where the currency symbol is in a sibling element.
   * Returns { contextText, selStartInCtx, selEndInCtx } or null.
   */
  function getSelectionContext(range, contextRadius) {
    const r = contextRadius || 40;
    try {
      let ancestor = range.commonAncestorContainer;
      if (!ancestor) return null;
      if (ancestor.nodeType === Node.TEXT_NODE) {
        ancestor = ancestor.parentElement;
      }
      if (!ancestor) return null;

      // Safety check: only go up to grandparent if text length is reasonable
      if (ancestor.textContent && ancestor.textContent.length < 1000) {
        if (["SPAN", "A", "B", "I", "EM", "STRONG", "FONT", "SMALL"].includes(ancestor.tagName)) {
          if (ancestor.parentElement && ancestor.parentElement.textContent && ancestor.parentElement.textContent.length < 1500) {
            ancestor = ancestor.parentElement;
          }
        }
      }

      // Calculate selection offsets relative to the ancestor's textContent
      let startOffset = -1;
      let endOffset = -1;
      let currentLength = 0;

      function traverse(node) {
        if (node.nodeType === Node.TEXT_NODE) {
          if (node === range.startContainer) {
            startOffset = currentLength + range.startOffset;
          }
          if (node === range.endContainer) {
            endOffset = currentLength + range.endOffset;
          }
          currentLength += node.textContent.length;
        } else {
          for (let child = node.firstChild; child; child = child.nextSibling) {
            traverse(child);
          }
        }
      }

      traverse(ancestor);
      if (startOffset === -1 || endOffset === -1) return null;

      const nodeText = ancestor.textContent || "";
      // Build a context window around the selection
      const ctxStart = Math.max(0, startOffset - r);
      const ctxEnd = Math.min(nodeText.length, endOffset + r);
      const contextText = nodeText.slice(ctxStart, ctxEnd);

      // Where within contextText does the selection sit?
      const selStartInCtx = startOffset - ctxStart;
      const selEndInCtx = endOffset - ctxStart;

      return { contextText, selStartInCtx, selEndInCtx };
    } catch (e) {
      console.error("Error getting selection context:", e);
      return null;
    }
  }

  /**
   * Run currency detection on an expanded context string.
   * Returns the parsed result whose match overlaps [selStart, selEnd],
   * preferring the one with the most overlap. Falls back to any match
   * if nothing overlaps exactly.
   */
  function detectInContext(contextText, selStartInCtx, selEndInCtx, defaultCurrency) {
    if (!contextText || contextText.length > 400) return null;

    // Use ONLY the selected text as the amount to convert
    const selectedText = contextText.slice(selStartInCtx, selEndInCtx).trim();
    const numMatch = selectedText.match(/^[+-]?\d[\d,.]*(?:\s*[kKmMbBtT])?$/i);
    if (!numMatch) return null;

    let amount = normalizeAmount(numMatch[0]);
    if (!Number.isFinite(amount)) return null;

    // Check for a negative sign just before the selection in context
    const prefix = contextText.slice(Math.max(0, selStartInCtx - 3), selStartInCtx);
    if (/-\s*$/.test(prefix)) amount = -Math.abs(amount);

    // Scan the full context for the closest currency token (symbol or code)
    RE_TOKEN.lastIndex = 0;
    const tokenRegex = RE_TOKEN;
    let tokenMatch = null;
    let closestToken = null;
    let minDistance = Infinity;

    while ((tokenMatch = tokenRegex.exec(contextText)) !== null) {
      const tStart = tokenMatch.index;
      const tEnd   = tokenMatch.index + tokenMatch[0].length;

      // Skip tokens that overlap the selected text itself
      if (tStart < selEndInCtx && tEnd > selStartInCtx) continue;

      const dist = tEnd <= selStartInCtx
        ? selStartInCtx - tEnd
        : tStart - selEndInCtx;

      if (dist < minDistance) {
        minDistance = dist;
        closestToken = tokenMatch[0];
      }
    }

    if (closestToken && minDistance <= 40) {
      const upper = closestToken.toUpperCase();
      const lower = closestToken.toLowerCase();
      const code = SYMBOL_TO_CODE[closestToken] || NAME_TO_CODE[lower] || (CODES.includes(upper) ? upper : null);
      if (code) return { code, amount };
    }

    // No currency symbol nearby — fall back to the user's base currency
    if (defaultCurrency) return { code: defaultCurrency, amount };

    return null;
  }

  function getLocale(currency) {
    if (!currency) return "en-US";
    switch (currency.toUpperCase()) {
      case "INR": return "en-IN";
      case "EUR": return "de-DE";
      case "GBP": return "en-GB";
      case "JPY": return "ja-JP";
      case "CNY": return "zh-CN";
      case "RUB": return "ru-RU";
      case "KRW": return "ko-KR";
      case "BRL": return "pt-BR";
      case "CAD": return "en-CA";
      case "AUD": return "en-AU";
      default: return "en-US";
    }
  }

  function multiplySafe(amount, rate) {
    if (!Number.isFinite(amount) || !Number.isFinite(rate)) return 0;
    const amountStr = amount.toString();
    const rateStr = rate.toString();
    if (amountStr.includes("e") || rateStr.includes("e")) {
      return amount * rate;
    }
    const amountDec = amountStr.includes(".") ? amountStr.split(".")[1].length : 0;
    const rateDec = rateStr.includes(".") ? rateStr.split(".")[1].length : 0;
    if (amountDec + rateDec > 12) {
      return Number((amount * rate).toFixed(12));
    }
    const factor = Math.pow(10, amountDec + rateDec);
    const intAmount = Math.round(amount * Math.pow(10, amountDec));
    const intRate = Math.round(rate * Math.pow(10, rateDec));
    return (intAmount * intRate) / factor;
  }

  function format(amount, currency, maximumFractionDigits = 2) {
    try {
      const locale = getLocale(currency);
      const baseFormatter = new Intl.NumberFormat(locale, {
        style: "currency",
        currency,
      });
      const resolvedOpts = baseFormatter.resolvedOptions();
      const standardDigits = resolvedOpts.minimumFractionDigits;

      const hasDecimals = amount % 1 !== 0;
      const decCount = hasDecimals ? amount.toString().split(".")[1].length : 0;
      const minDigits = Math.min(Math.max(standardDigits, decCount), maximumFractionDigits);

      return new Intl.NumberFormat(locale, {
        style: "currency",
        currency,
        minimumFractionDigits: minDigits,
        maximumFractionDigits,
      }).format(amount);
    } catch {
      return `${amount.toFixed(maximumFractionDigits)} ${currency}`;
    }
  }

  function formatRate(rate, target) {
    return format(rate, target, 6).replace(/^[^\d-]+/, "");
  }

  function positiveNumber(value) {
    const number = Number(value);
    return Number.isFinite(number) && number > 0 ? number : null;
  }

  function getCrossRate(settings, from, to) {
    if (!from || !to) return null;
    if (from === to) return 1;

    const base = settings.baseCurrency;
    const target = settings.targetCurrency;
    const manualRate = positiveNumber(settings.exchangeRate);
    const rates = settings.rates || {};

    // 1. If manual rate is defined and we are converting between base and target
    if (manualRate) {
      if (from === base && to === target) return manualRate;
      if (from === target && to === base) return 1 / manualRate;
    }

    // 2. Otherwise use fetched rates
    const fromRate = positiveNumber(rates[from]);
    const toRate = positiveNumber(rates[to]);

    if (from === base && toRate) return toRate;
    if (to === base && fromRate) return 1 / fromRate;
    if (fromRate && toRate) return toRate / fromRate;

    return null;
  }

  function sourceText(settings) {
    if (!settings.lastUpdated) return "manual rate";
    const timestamp = Number(settings.lastUpdated);
    if (!Number.isFinite(timestamp)) return "manual rate";
    const age = Date.now() - timestamp;
    const date = new Date(timestamp).toLocaleDateString();
    return `${settings.rateProvider || "saved rate"} · ${date}${age > STALE_AFTER_MS ? " · stale" : ""}`;
  }

  function getRateStatus(settings) {
    if (!settings.lastUpdated) return "offline";
    const age = Date.now() - Number(settings.lastUpdated);
    if (!Number.isFinite(age)) return "offline";
    return age <= STALE_AFTER_MS ? "live" : "stale";
  }

  /** Returns true if this conversion is allowed (premium or under free limit) */
  async function canConvert() {
    if (IS_DEV) return true;
    if (!isContextValid()) return false;
    // Premium users: unlimited (require authToken to be present)
    const isPremiumUser = settingsCache.authToken && settingsCache.subscriptionActive === true;
    if (isPremiumUser) return true;
    try {
      // Free users: check count
      const stored = await chrome.storage.local.get(["conversionsUsed"]);
      const used = Number(stored.conversionsUsed) || 0;
      return used < FREE_CONVERSION_LIMIT;
    } catch {
      return false;
    }
  }

  /** Increments the conversion counter for free-tier tracking */
  async function trackConversion() {
    if (IS_DEV) return;
    if (!isContextValid()) return;
    const isPremiumUser = settingsCache.authToken && settingsCache.subscriptionActive === true;
    if (isPremiumUser) return; // don't track for premium
    try {
      const stored = await chrome.storage.local.get(["conversionsUsed"]);
      const used = Number(stored.conversionsUsed) || 0;
      const next = used + 1;
      await chrome.storage.local.set({ conversionsUsed: next });
      settingsCache.conversionsUsed = next;
    } catch {
      // Storage quota or access error — non-fatal, skip tracking
    }
  }

  /**
   * Refreshes the premium subscription status cache.
   * Always returns true — access gating is handled by canConvert().
   * Free-tier users (no token) are allowed; the conversion limit is enforced separately.
   */
  async function verifyPremiumFromBackend() {
    if (IS_DEV) return true;
    if (!isContextValid()) return false;
    const token = settingsCache.authToken;

    // No token = free-tier user. Allow conversion; canConvert() enforces the limit.
    if (!token) return true;

    // Use cached status if checked within the last 5 minutes
    const lastChecked = Number(settingsCache.subscriptionCheckedAt) || 0;
    const cacheAge = Date.now() - lastChecked;
    const cacheDuration = 5 * 60 * 1000;

    if (settingsCache.subscriptionActive !== undefined && cacheAge < cacheDuration) {
      return true; // Cached — premium or free, canConvert() handles the distinction
    }

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);
      const res = await fetch(`${API_BASE_URL}/api/subscription/status`, {
        headers: { authorization: `Bearer ${token}` },
        signal: controller.signal,
      });
      clearTimeout(timeoutId);
      if (res.status === 401 || res.status === 403) {
        if (!isContextValid()) return false;
        await chrome.storage.local.set({
          authToken: null,
          authUser: null,
          subscriptionStatus: null,
          subscriptionActive: false,
          subscriptionCheckedAt: Date.now(),
        });
        settingsCache.authToken = null;
        settingsCache.subscriptionActive = false;
        return true;
      }
      const subscription = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(subscription.error || `HTTP ${res.status}`);

      const active = subscription.active === true && subscription.status === "active";
      if (!isContextValid()) return false;
      await chrome.storage.local.set({
        subscriptionStatus: subscription,
        subscriptionActive: active,
        subscriptionCheckedAt: Date.now(),
      });
    } catch {
      // Network error — persist cached state, fail open so free users aren't blocked
      if (!isContextValid()) return false;
      try {
        await chrome.storage.local.set({
          subscriptionActive: settingsCache.subscriptionActive ?? false,
          subscriptionCheckedAt: Date.now(),
        });
      } catch {
        // Safe ignore
      }
    }
    return true; // Always allow — canConvert() enforces free vs premium limits
  }

  function makeEl(tag, className, text) {
    const el = document.createElement(tag);
    if (className) el.className = className;
    if (text !== undefined) el.textContent = text;
    return el;
  }

  function copyText(text) {
    if (navigator.clipboard?.writeText) return navigator.clipboard.writeText(text);

    return new Promise((resolve, reject) => {
      const input = document.createElement("textarea");
      input.value = text;
      input.setAttribute("readonly", "");
      input.style.position = "fixed";
      input.style.top = "-9999px";
      input.style.opacity = "0";
      document.documentElement.appendChild(input);
      input.select();

      try {
        if (document.execCommand("copy")) resolve();
        else reject(new Error("Copy unsupported"));
      } catch (e) {
        reject(e);
      } finally {
        input.remove();
      }
    });
  }

  function ensureTooltip() {
    if (tooltip) return tooltip;

    tooltip = makeEl("div", "ic-tooltip");
    tooltip.setAttribute("role", "tooltip");
    tooltip.setAttribute("aria-live", "polite");
    tooltip.setAttribute("aria-atomic", "true");

    // Body: hero converted amount + origin row
    const body = makeEl("div", "ic-tooltip-body");

    // Hero: converted amount split into main + decimal
    const toWrap = makeEl("div", "ic-to-wrap");
    toWrap.setAttribute("aria-label", "Converted amount");
    const toMain = makeEl("span", "ic-to-main");
    const toDec  = makeEl("span", "ic-to-dec");
    toWrap.append(toMain, toDec);

    // Origin row: from amount + arrow
    const originRow = makeEl("div", "ic-origin-row");
    const from  = makeEl("span", "ic-from");
    from.setAttribute("aria-label", "Original amount");
    const arrow = makeEl("span", "ic-arrow", "→");
    arrow.setAttribute("aria-hidden", "true");
    originRow.append(from, arrow);

    body.append(toWrap, originRow);

    // Trust row: rate text + status dot + copy button
    const trustRow = makeEl("div", "ic-trust-row");
    const rate = makeEl("span", "ic-rate");
    rate.setAttribute("aria-label", "Exchange rate");
    const dot  = makeEl("span", "ic-dot offline");
    dot.setAttribute("aria-hidden", "true");
    dot.title = "Rate status";

    // Copy button with clipboard SVG icon
    const copy = document.createElement("button");
    copy.className = "ic-copy";
    copy.type = "button";
    copy.title = "Copy converted amount";
    copy.setAttribute("aria-label", "Copy converted amount");
    copy.innerHTML = `<svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><rect x="4.5" y="4.5" width="7" height="7" rx="1.5" stroke="currentColor" stroke-width="1.2"/><path d="M3 8.5H2A1.5 1.5 0 0 1 .5 7V2A1.5 1.5 0 0 1 2 .5H7A1.5 1.5 0 0 1 8.5 2v1" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>`;
    copy.addEventListener("click", (e) => {
      e.stopPropagation();
      const text = toMain.textContent + toDec.textContent;
      copyText(text)
        .then(() => {
          copy.classList.add("copied");
          copy.innerHTML = `<svg width="13" height="13" viewBox="0 0 13 13" fill="none" aria-hidden="true"><path d="M2 6.5L5 9.5L11 3.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
          setTimeout(() => {
            copy.classList.remove("copied");
            copy.innerHTML = `<svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><rect x="4.5" y="4.5" width="7" height="7" rx="1.5" stroke="currentColor" stroke-width="1.2"/><path d="M3 8.5H2A1.5 1.5 0 0 1 .5 7V2A1.5 1.5 0 0 1 2 .5H7A1.5 1.5 0 0 1 8.5 2v1" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>`;
          }, 1200);
        })
        .catch(() => {});
    });

    trustRow.append(rate, dot, copy);

    // Keyboard hint: press C to copy
    const hint = makeEl("div", "ic-hint");
    hint.setAttribute("aria-hidden", "true");
    hint.innerHTML = `Press <kbd>C</kbd> to copy`;

    tooltip.append(body, trustRow, hint);
    document.documentElement.appendChild(tooltip);

    // Store refs on tooltip for quick access
    tooltip._from   = from;
    tooltip._toMain = toMain;
    tooltip._toDec  = toDec;
    tooltip._rate   = rate;
    tooltip._dot    = dot;
    tooltip._hint   = hint;

    return tooltip;
  }

  function hideTooltip() {
    if (tooltip) tooltip.classList.remove("ic-visible");
  }

  function showTooltip(x, y, fromText, toText, rateText, rateStatus) {
    const tip = ensureTooltip();

    // Split toText into integer + decimal for hero typography
    const dotIdx = toText.lastIndexOf(".");
    const hasDecimal = dotIdx !== -1 && dotIdx < toText.length - 1;
    if (hasDecimal) {
      tip._toMain.textContent = toText.slice(0, dotIdx);
      tip._toDec.textContent  = toText.slice(dotIdx);
    } else {
      tip._toMain.textContent = toText;
      tip._toDec.textContent  = "";
    }

    tip._from.textContent = fromText;
    tip._rate.textContent = rateText;

    // Trust dot
    const dot = tip._dot;
    dot.className = "ic-dot " + (rateStatus || "offline");
    dot.title = rateStatus === "live" ? "Live rate" : rateStatus === "stale" ? "Stale — tap to refresh" : "Cached offline";

    // Position: measure first at (0,0)
    tip.style.left = "0px";
    tip.style.top  = "0px";
    tip.classList.add("ic-visible");

    const tipRect = tip.getBoundingClientRect();
    const pad = 12;
    let left = x - tipRect.width / 2;
    let top  = y - tipRect.height - 14;

    // Prefer above; fall back to below if clipped
    if (top < pad) top = y + 16;
    // Clamp horizontal
    left = Math.max(pad, Math.min(window.innerWidth - tipRect.width - pad, left));

    tip.style.left = `${left + window.scrollX}px`;
    tip.style.top  = `${top  + window.scrollY}px`;
  }

  async function handleSelection(composedPath) {
    try {
      if (!isContextValid()) return;
      await settingsLoadedPromise;
      if (settingsCache.pageTooltipEnabled === false) {
        hideTooltip();
        return;
      }

      let text = "";
      let rect = null;
      let selRange = null;

      const sel = window.getSelection();
      if (sel && !sel.isCollapsed && sel.rangeCount > 0) {
        const t = sel.toString().trim();
        if (t) {
          text = t;
          selRange = sel.getRangeAt(0);
          rect = selRange.getBoundingClientRect();
        }
      }

      if (!text && composedPath) {
        for (const node of composedPath) {
          if (!node) continue;
          const root = node.shadowRoot || (node.getRootNode && node.getRootNode());
          if (root && root !== document && typeof root.getSelection === "function") {
            const shadowSel = root.getSelection();
            if (shadowSel && !shadowSel.isCollapsed && shadowSel.rangeCount > 0) {
              const t = shadowSel.toString().trim();
              if (t) {
                text = t;
                selRange = shadowSel.getRangeAt(0);
                rect = selRange.getBoundingClientRect();
                break;
              }
            }
          }
        }
      }

      if (!text) {
        hideTooltip();
        return;
      }

      // --- Primary detection: try the exact selected text first ---
      let parsed = detect(text);

      // --- Fallback: expand context window from the surrounding text node ---
      if (!parsed && selRange) {
        const ctx = getSelectionContext(selRange, 40);
        const baseCur = settingsCache.baseCurrency || "USD";
        if (ctx) {
          parsed = detectInContext(ctx.contextText, ctx.selStartInCtx, ctx.selEndInCtx, baseCur);
        }
        // Last resort: if the raw selected text is a bare number, convert it with base currency
        if (!parsed) {
          const bareNum = text.replace(/,/g, "").trim();
          const n = parseFloat(bareNum);
          if (/^[\d,.]+$/.test(text.trim()) && Number.isFinite(n)) {
            parsed = { code: baseCur, amount: n };
          }
        }
      }

      if (!parsed) {
        hideTooltip();
        return;
      }

      if (!(await verifyPremiumFromBackend())) {
        hideTooltip();
        return;
      }

      const target = settingsCache.targetCurrency;
      if (!target) {
        hideTooltip();
        return;
      }

      const rate = getCrossRate(settingsCache, parsed.code, target);
      if (!rate || !Number.isFinite(rate)) {
        hideTooltip();
        return;
      }

      // Check free-tier conversion limit
      if (!(await canConvert())) {
        if (rect) {
          showTooltip(
            rect.left + rect.width / 2,
            rect.top,
            "🚫 Free limit reached",
            `0 of ${FREE_CONVERSION_LIMIT}`,
            "Get Lifetime Access at $4.99 — open the extension popup.",
            "offline"
          );
        }
        return;
      }

      const converted = multiplySafe(parsed.amount, rate);
      const fromText  = format(parsed.amount, parsed.code);
      const toText    = format(converted, target);
      const rateText  = `1 ${parsed.code} = ${formatRate(rate, target)} ${target} · ${sourceText(settingsCache)}`;
      const rateStatus = getRateStatus(settingsCache);

      if (rect) {
        showTooltip(rect.left + rect.width / 2, rect.top, fromText, toText, rateText, rateStatus);
        // Track usage after successful conversion
        trackConversion();
      }
    } catch (e) {
      if (e.message?.includes("Extension context invalidated")) {
        return;
      }
      console.error("HoverConvert: handleSelection error", e);
    }
  }

  let hoverTimeout = null;
  let hideTimeout = null;
  let hoveredElement = null;

  async function handleHover(targetEl) {
    try {
      if (!isContextValid()) return;
      await settingsLoadedPromise;
      if (settingsCache.pageTooltipEnabled === false) {
        return;
      }

      // Skip if there's an active text selection
      const sel = window.getSelection();
      if (sel && !sel.isCollapsed && sel.toString().trim() !== "") {
        return;
      }

      // Skip input fields, buttons, links, etc.
      if (["INPUT", "TEXTAREA", "BUTTON", "SELECT", "OPTION", "A"].includes(targetEl.tagName)) {
        return;
      }

      const text = targetEl.textContent?.trim();
      if (!text || text.length > 60) {
        return;
      }

      const parsed = detect(text);
      if (!parsed) {
        return;
      }

      if (!(await verifyPremiumFromBackend())) {
        return;
      }

      const target = settingsCache.targetCurrency;
      if (!target) {
        return;
      }

      const rate = getCrossRate(settingsCache, parsed.code, target);
      if (!rate || !Number.isFinite(rate)) {
        return;
      }

      const converted  = multiplySafe(parsed.amount, rate);
      const fromText   = format(parsed.amount, parsed.code);
      const toText     = format(converted, target);
      const rateText   = `1 ${parsed.code} = ${formatRate(rate, target)} ${target} · ${sourceText(settingsCache)}`;
      const rateStatus = getRateStatus(settingsCache);

      const rect = targetEl.getBoundingClientRect();
      showTooltip(rect.left + rect.width / 2, rect.top, fromText, toText, rateText, rateStatus);
      hoveredElement = targetEl;

      // Auto-hide the keyboard hint after 3 seconds
      if (tooltip && tooltip._hint) {
        clearTimeout(tooltip._hintTimer);
        tooltip._hint.style.opacity = "1";
        tooltip._hintTimer = setTimeout(() => {
          if (tooltip && tooltip._hint) tooltip._hint.style.opacity = "0";
        }, 3000);
      }
    } catch (e) {
      if (e.message?.includes("Extension context invalidated")) {
        return;
      }
      console.error("HoverConvert: handleHover error", e);
    }
  }

  function distanceToRect(x, y, rect) {
    const dx = Math.max(rect.left - x, 0, x - rect.right);
    const dy = Math.max(rect.top - y, 0, y - rect.bottom);
    return Math.sqrt(dx * dx + dy * dy);
  }

  document.addEventListener("mousemove", (e) => {
    if (!isContextValid()) return;
    const targetEl = e.target;
    if (!targetEl) return;

    const mouseX = e.clientX;
    const mouseY = e.clientY;

    let isNearActive = false;

    if (tooltip && tooltip.classList.contains("ic-visible")) {
      const tooltipRect = tooltip.getBoundingClientRect();
      const distToTooltip = distanceToRect(mouseX, mouseY, tooltipRect);

      let distToHovered = Infinity;
      if (hoveredElement) {
        const hoveredRect = hoveredElement.getBoundingClientRect();
        distToHovered = distanceToRect(mouseX, mouseY, hoveredRect);
      }

      // If within 40px of either the tooltip or the hovered element, keep it active
      if (distToTooltip < 40 || distToHovered < 40) {
        isNearActive = true;
      }
    }

    if (isNearActive) {
      if (hideTimeout) {
        clearTimeout(hideTimeout);
        hideTimeout = null;
      }
    } else {
      // If we are not near the active zones, schedule hiding
      if (tooltip && tooltip.classList.contains("ic-visible") && !hideTimeout) {
        hideTimeout = setTimeout(() => {
          hideTooltip();
          hoveredElement = null;
          hideTimeout = null;
        }, 300);
      }
    }

    // Debounce hover detection for any new element (avoid triggering if inside the tooltip)
    if (hoverTimeout) {
      clearTimeout(hoverTimeout);
    }

    const isInsideTooltip = tooltip && tooltip.contains(targetEl);
    if (!isInsideTooltip) {
      hoverTimeout = setTimeout(() => {
        handleHover(targetEl);
      }, 200);
    }
  });

  document.addEventListener("mouseup", (e) => {
    if (!isContextValid()) return;
    const path = e.composedPath ? e.composedPath() : null;
    setTimeout(() => {
      if (isContextValid()) handleSelection(path);
    }, 10);
  });
  document.addEventListener("keyup", (e) => {
    if (!isContextValid()) return;
    if (e.key === "Shift" || e.shiftKey) {
      const path = [];
      let curr = document.activeElement;
      while (curr) {
        path.push(curr);
        curr = curr.shadowRoot ? curr.shadowRoot.activeElement : null;
      }
      setTimeout(() => {
        if (isContextValid()) handleSelection(path);
      }, 10);
    }
  });
  document.addEventListener("keydown", (e) => {
    if (!isContextValid()) return;
    if (e.key === "Escape") {
      hideTooltip();
      hoveredElement = null;
    }
    // C key: copy converted amount when tooltip is visible
    if (e.key === "c" || e.key === "C") {
      if (
        tooltip &&
        tooltip.classList.contains("ic-visible") &&
        !e.ctrlKey && !e.metaKey &&
        document.activeElement?.tagName !== "INPUT" &&
        document.activeElement?.tagName !== "TEXTAREA"
      ) {
        const text = (tooltip._toMain?.textContent || "") + (tooltip._toDec?.textContent || "");
        if (text) {
          copyText(text).then(() => {
            if (tooltip._dot) {
              tooltip._dot.style.background = "#34d399";
              setTimeout(() => { if (tooltip._dot) tooltip._dot.style.background = ""; }, 800);
            }
          }).catch(() => {});
        }
      }
    }
  });
  document.addEventListener("mousedown", (e) => {
    if (!isContextValid()) return;
    if (tooltip && !tooltip.contains(e.target)) {
      hideTooltip();
      hoveredElement = null;
      if (hideTimeout) {
        clearTimeout(hideTimeout);
        hideTimeout = null;
      }
    }
  });
  document.addEventListener("scroll", () => {
    if (!isContextValid()) return;
    hideTooltip();
    hoveredElement = null;
    if (hoverTimeout) {
      clearTimeout(hoverTimeout);
      hoverTimeout = null;
    }
    if (hideTimeout) {
      clearTimeout(hideTimeout);
      hideTimeout = null;
    }
  }, { passive: true });
})();
