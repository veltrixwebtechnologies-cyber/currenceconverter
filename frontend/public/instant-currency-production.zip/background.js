importScripts("config.js");

const CONFIG = globalThis.INSTANT_CURRENCY_CONFIG || {};

const API_BASE_URL = (CONFIG.API_BASE_URL || "").replace(/\/$/, "");
const ACCOUNT_ORIGIN = CONFIG.ACCOUNT_ORIGIN || (CONFIG.ACCOUNT_URL ? new URL(CONFIG.ACCOUNT_URL).origin : "");
const IS_DEV = CONFIG.ENV === "development" || (API_BASE_URL && (API_BASE_URL.includes("localhost") || API_BASE_URL.includes("127.0.0.1")));

function isAllowedSender(sender) {
  try {
    if (!sender.url) return false;
    const origin = new URL(sender.url).origin;
    if (origin === ACCOUNT_ORIGIN) return true;
    if (IS_DEV && (origin.startsWith("http://localhost:") || origin.startsWith("http://127.0.0.1:"))) {
      return true;
    }
    return false;
  } catch {
    return false;
  }
}

function isPremium(subscription) {
  if (!subscription || subscription.active !== true || subscription.status !== "active") return false;
  if (!subscription.expires_at) return true;
  return new Date(subscription.expires_at).getTime() > Date.now();
}

chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (!isAllowedSender(sender)) {
    sendResponse({ ok: false, error: "Sender origin is not allowed" });
    return false;
  }

  if (message?.type !== "INSTANT_CURRENCY_CLERK_SESSION") {
    sendResponse({ ok: false, error: "Invalid message type" });
    return false;
  }

  if (!message.token || !message.user?.id) {
    // Clear session on logout
    chrome.storage.local.set({
      authToken: null,
      authUser: null,
      subscriptionStatus: null,
      subscriptionActive: false,
      subscriptionCheckedAt: Date.now(),
    }).then(() => {
      sendResponse({ ok: true, action: "clear" });
    }).catch((error) => {
      sendResponse({ ok: false, error: error.message });
    });
    return true;
  }

  chrome.storage.local.set({
    authToken: message.token,
    authUser: message.user,
    subscriptionStatus: message.subscription || { active: false, status: "inactive", plan_type: "free" },
    subscriptionActive: isPremium(message.subscription),
    subscriptionCheckedAt: Date.now(),
  }).then(() => {
    sendResponse({ ok: true, action: "sync" });
  }).catch((error) => {
    sendResponse({ ok: false, error: error.message });
  });

  return true;
});

// Set sensible defaults on first install
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["baseCurrency", "targetCurrency"], (settings) => {
    const updates = {};
    if (!settings.baseCurrency) updates.baseCurrency = "USD";
    if (!settings.targetCurrency) updates.targetCurrency = "INR";
    if (Object.keys(updates).length > 0) {
      chrome.storage.local.set(updates);
    }
  });
});

