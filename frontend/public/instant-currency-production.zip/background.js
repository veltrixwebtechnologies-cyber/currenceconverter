importScripts("config.js");

const CONFIG = globalThis.INSTANT_CURRENCY_CONFIG || {};

const API_BASE_URL = (CONFIG.API_BASE_URL || "").replace(/\/$/, "");
const ACCOUNT_ORIGIN = CONFIG.ACCOUNT_ORIGIN || (CONFIG.ACCOUNT_URL ? new URL(CONFIG.ACCOUNT_URL).origin : "");
const IS_DEV = CONFIG.ENV === "development" || (API_BASE_URL && (API_BASE_URL.includes("localhost") || API_BASE_URL.includes("127.0.0.1")));

// ── Rate refresh constants ──
const RATE_ALARM_NAME = "hc_rate_refresh";
const RATE_REFRESH_INTERVAL_MIN = 6 * 60; // 6 hours in minutes
const RATE_STALE_MS = 12 * 60 * 60 * 1000; // 12 hours — rates are valid this long
const RATE_API_TIMEOUT_MS = 15000;

// ── Auth helpers ──

function isAllowedSender(sender) {
  try {
    if (!sender.url) return false;
    const origin = new URL(sender.url).origin;
    if (origin === ACCOUNT_ORIGIN) return true;
    if (IS_DEV && (origin.startsWith("http://localhost:") || origin.startsWith("http://127.0.0.1:"))) {
      return true;
    }
    return false;
  } catch {
    return false;
  }
}

function isPremium(subscription) {
  if (!subscription || subscription.active !== true || subscription.status !== "active") return false;
  if (!subscription.expires_at) return true;
  return new Date(subscription.expires_at).getTime() > Date.now();
}

// ── Rate fetching ──

/**
 * Fetches latest exchange rates from ExchangeRate-API and saves to chrome.storage.
 * This is the single source of truth for rate data across popup and content scripts.
 *
 * Flow:
 *   Extension Installed → Fetch rates → Save in Chrome Storage
 *   → Use cached rates for hovering → Refresh after 6-12 hours
 *
 * @param {string} baseCurrency - The base currency code (e.g. "USD")
 * @returns {boolean} true if rates were successfully fetched and saved
 */
async function fetchAndCacheRates(baseCurrency) {
  if (!baseCurrency) return false;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), RATE_API_TIMEOUT_MS);

  try {
    const res = await fetch(
      `https://open.er-api.com/v6/latest/${encodeURIComponent(baseCurrency)}`,
      { signal: controller.signal }
    );
    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const data = await res.json();
    if (data?.result !== "success") throw new Error(data?.["error-type"] || "API error");

    const rates = data.rates || {};
    const lastUpdated = data.time_last_update_unix
      ? Number(data.time_last_update_unix) * 1000
      : Date.now();
    const lastUpdatedUtc = data.time_last_update_utc || new Date(lastUpdated).toUTCString();

    // Persist rates + metadata to chrome.storage.local
    await chrome.storage.local.set({
      rates,
      lastUpdated,
      lastUpdatedUtc,
      rateProvider: "ExchangeRate-API",
    });

    console.log(`[HoverConvert] Rates refreshed for ${baseCurrency} at ${lastUpdatedUtc}`);
    return true;
  } catch (e) {
    console.warn("[HoverConvert] Rate fetch failed:", e.message);
    return false;
  } finally {
    clearTimeout(timeout);
  }
}

/**
 * Checks if cached rates are stale and refreshes them if needed.
 * Only auto-fetches for premium users; free users keep their cached/manual rates.
 */
async function refreshRatesIfStale() {
  const settings = await chrome.storage.local.get([
    "baseCurrency",
    "lastUpdated",
    "rates",
    "authToken",
    "subscriptionActive",
  ]);

  const base = settings.baseCurrency || "USD";
  const lastUpdated = Number(settings.lastUpdated) || 0;
  const age = Date.now() - lastUpdated;
  const hasRates = settings.rates && Object.keys(settings.rates).length > 2;

  // If rates exist and are fresh, skip
  if (hasRates && lastUpdated > 0 && age < RATE_STALE_MS) {
    console.log("[HoverConvert] Rates still fresh, skipping refresh.");
    return;
  }

  // FIRST fetch (no rates at all) — allow for ALL users so everyone gets working rates
  if (!hasRates) {
    console.log("[HoverConvert] No cached rates found — fetching initial rates for all users.");
    await fetchAndCacheRates(base);
    return;
  }

  // Subsequent auto-refreshes — only for premium users
  const isPremiumUser = settings.authToken && settings.subscriptionActive === true;
  if (!isPremiumUser && !IS_DEV) {
    console.log("[HoverConvert] Free user — skipping periodic rate refresh.");
    return;
  }

  await fetchAndCacheRates(base);
}

// ── Alarm handler — fires every 6 hours ──

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === RATE_ALARM_NAME) {
    refreshRatesIfStale();
  }
});

// ── External message handler (website → extension sync) ──

chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (!isAllowedSender(sender)) {
    sendResponse({ ok: false, error: "Sender origin is not allowed" });
    return false;
  }

  if (message?.type !== "INSTANT_CURRENCY_CLERK_SESSION") {
    sendResponse({ ok: false, error: "Invalid message type" });
    return false;
  }

  if (!message.token || !message.user?.id) {
    // Clear session on logout
    chrome.storage.local.set({
      authToken: null,
      authUser: null,
      subscriptionStatus: null,
      subscriptionActive: false,
      subscriptionCheckedAt: Date.now(),
    }).then(() => {
      sendResponse({ ok: true, action: "clear" });
    }).catch((error) => {
      sendResponse({ ok: false, error: error.message });
    });
    return true;
  }

  fetch(`${API_BASE_URL}/api/subscription/status`, {
    headers: { "Authorization": `Bearer ${message.token}` }
  })
  .then(res => {
    if (res.status === 401 || res.status === 403) {
      throw new Error("Invalid or expired session token");
    }
    if (!res.ok) {
      throw new Error(`Server returned HTTP ${res.status}`);
    }
    return res.json();
  })
  .then(subscription => {
    const active = subscription.active === true && subscription.status === "active";
    chrome.storage.local.set({
      authToken: message.token,
      authUser: message.user,
      subscriptionStatus: subscription,
      subscriptionActive: active,
      subscriptionCheckedAt: Date.now(),
    }).then(() => {
      // If user just became premium, immediately refresh rates
      if (active) {
        refreshRatesIfStale();
      }
      sendResponse({ ok: true, action: "sync", active });
    });
  })
  .catch((error) => {
    console.error("Token verification failed during sync:", error);
    if (error.message.includes("session token")) {
      chrome.storage.local.set({
        authToken: null,
        authUser: null,
        subscriptionStatus: null,
        subscriptionActive: false,
        subscriptionCheckedAt: Date.now(),
      }).then(() => {
        sendResponse({ ok: false, error: error.message });
      });
    } else {
      sendResponse({ ok: false, error: error.message });
    }
  });

  return true;
});

// ── Extension lifecycle ──

chrome.runtime.onInstalled.addListener((details) => {
  // Set sensible defaults on first install
  chrome.storage.local.get(["baseCurrency", "targetCurrency"], (settings) => {
    const updates = {};
    if (!settings.baseCurrency) updates.baseCurrency = "USD";
    if (!settings.targetCurrency) updates.targetCurrency = "INR";
    if (Object.keys(updates).length > 0) {
      chrome.storage.local.set(updates);
    }
  });

  // Schedule the periodic rate refresh alarm (every 6 hours)
  chrome.alarms.create(RATE_ALARM_NAME, {
    delayInMinutes: 1,                    // First run 1 minute after install
    periodInMinutes: RATE_REFRESH_INTERVAL_MIN, // Then every 6 hours
  });

  // On fresh install, fetch rates immediately with default base currency
  if (details.reason === "install") {
    // Small delay to let defaults settle
    setTimeout(() => {
      chrome.storage.local.get(["baseCurrency"], (s) => {
        fetchAndCacheRates(s.baseCurrency || "USD");
      });
    }, 2000);
  }
});

// ── Service worker startup — ensure alarm exists ──
// (alarms persist across service worker restarts, but re-create if missing)
chrome.alarms.get(RATE_ALARM_NAME, (alarm) => {
  if (!alarm) {
    chrome.alarms.create(RATE_ALARM_NAME, {
      delayInMinutes: 1,
      periodInMinutes: RATE_REFRESH_INTERVAL_MIN,
    });
    console.log("[HoverConvert] Rate refresh alarm re-created on startup.");
  }
});
