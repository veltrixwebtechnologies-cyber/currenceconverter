// Production config for Instant Currency extension.
//
// PAYMENT INTEGRATION: Not yet enabled.
// When your backend is ready, set API_BASE_URL to your API server (e.g. https://api.currenceconverter.me).
// Until then, leave it empty — the extension works fully for free-tier users without a backend.
globalThis.INSTANT_CURRENCY_CONFIG = {
  API_BASE_URL: "https://www.currenceconverter.me",
  ACCOUNT_URL:  "https://www.currenceconverter.me",
  ACCOUNT_ORIGIN: "https://www.currenceconverter.me",
};
