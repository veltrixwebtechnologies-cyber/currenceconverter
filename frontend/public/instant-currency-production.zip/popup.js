const CURRENCIES = [
  "USD","EUR","GBP","INR","JPY","CNY","AUD","CAD","CHF","NZD","SGD","HKD",
  "SEK","NOK","DKK","KRW","MXN","BRL","ZAR","TRY","RUB","AED","SAR","THB",
  "IDR","MYR","PHP","PLN","CZK","HUF","ILS","VND","TWD",
];

const CURRENCY_NAMES = {
  USD: "US Dollar",
  EUR: "Euro",
  GBP: "British Pound",
  INR: "Indian Rupee",
  JPY: "Japanese Yen",
  CNY: "Chinese Yuan",
  AUD: "Australian Dollar",
  CAD: "Canadian Dollar",
  CHF: "Swiss Franc",
  NZD: "New Zealand Dollar",
  SGD: "Singapore Dollar",
  HKD: "Hong Kong Dollar",
  SEK: "Swedish Krona",
  NOK: "Norwegian Krone",
  DKK: "Danish Krone",
  KRW: "South Korean Won",
  MXN: "Mexican Peso",
  BRL: "Brazilian Real",
  ZAR: "South African Rand",
  TRY: "Turkish Lira",
  RUB: "Russian Ruble",
  AED: "UAE Dirham",
  SAR: "Saudi Riyal",
  THB: "Thai Baht",
  IDR: "Indonesian Rupiah",
  MYR: "Malaysian Ringgit",
  PHP: "Philippine Peso",
  PLN: "Polish Zloty",
  CZK: "Czech Koruna",
  HUF: "Hungarian Forint",
  ILS: "Israeli Shekel",
  VND: "Vietnamese Dong",
  TWD: "Taiwan Dollar",
};

const STALE_AFTER_MS = 1 * 60 * 60 * 1000;
const FREE_CONVERSION_LIMIT = 100;
const API_TIMEOUT_MS = 12000;
const CONFIG = globalThis.INSTANT_CURRENCY_CONFIG || {};
// API_BASE_URL is always provided by config.js. No localhost fallback in production.
const API_BASE_URL = (CONFIG.API_BASE_URL || "").replace(/\/$/, "");
const ACCOUNT_URL = CONFIG.ACCOUNT_URL || API_BASE_URL;
const IS_DEV = CONFIG.ENV === "development" || (API_BASE_URL && (API_BASE_URL.includes("localhost") || API_BASE_URL.includes("127.0.0.1")));
const $ = (id) => document.getElementById(id);

let saveTimer = null;
let accountState = {
  token: null,
  user: null,
  subscription: { active: false, status: "inactive", plan_type: "free" },
};

const memoryStore = {};
const storage = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local
  ? chrome.storage.local
  : {
      async get(keys) {
        if (Array.isArray(keys)) {
          return Object.fromEntries(
            keys
              .map((key) => [key, memoryStore[key]])
              .filter(([, value]) => value !== undefined)
          );
        }
        return { ...memoryStore };
      },
      async set(updates) {
        Object.assign(memoryStore, updates);
      },
      async remove(keys) {
        for (const key of keys) delete memoryStore[key];
      },
    };

function setStatus(id, message, type = "") {
  const el = $(id);
  el.className = `status${type ? ` ${type}` : ""}`;
  el.textContent = message || "";
}

function getLocale(currency) {
  if (!currency) return "en-US";
  switch (currency.toUpperCase()) {
    case "INR": return "en-IN";
    case "EUR": return "de-DE";
    case "GBP": return "en-GB";
    case "JPY": return "ja-JP";
    case "CNY": return "zh-CN";
    case "RUB": return "ru-RU";
    case "KRW": return "ko-KR";
    case "BRL": return "pt-BR";
    case "CAD": return "en-CA";
    case "AUD": return "en-AU";
    default: return "en-US";
  }
}

function multiplySafe(amount, rate) {
  if (!Number.isFinite(amount) || !Number.isFinite(rate)) return 0;
  const amountStr = amount.toString();
  const rateStr = rate.toString();
  if (amountStr.includes("e") || rateStr.includes("e")) {
    return amount * rate;
  }
  const amountDec = amountStr.includes(".") ? amountStr.split(".")[1].length : 0;
  const rateDec = rateStr.includes(".") ? rateStr.split(".")[1].length : 0;
  if (amountDec + rateDec > 12) {
    return Number((amount * rate).toFixed(12));
  }
  const factor = Math.pow(10, amountDec + rateDec);
  const intAmount = Math.round(amount * Math.pow(10, amountDec));
  const intRate = Math.round(rate * Math.pow(10, rateDec));
  return (intAmount * intRate) / factor;
}

function format(amount, currency, maximumFractionDigits = 2) {
  if (!currency) return amount.toFixed(maximumFractionDigits);
  try {
    const locale = getLocale(currency);
    const baseFormatter = new Intl.NumberFormat(locale, {
      style: "currency",
      currency,
    });
    const resolvedOpts = baseFormatter.resolvedOptions();
    const standardDigits = resolvedOpts.minimumFractionDigits;

    const hasDecimals = amount % 1 !== 0;
    const decCount = hasDecimals ? amount.toString().split(".")[1].length : 0;
    const minDigits = Math.min(Math.max(standardDigits, decCount), maximumFractionDigits);

    return new Intl.NumberFormat(locale, {
      style: "currency",
      currency,
      minimumFractionDigits: minDigits,
      maximumFractionDigits,
    }).format(amount);
  } catch {
    return `${amount.toFixed(maximumFractionDigits)} ${currency}`;
  }
}

function formatRate(rate, target) {
  return format(rate, target, 6).replace(/^[^\d-]+/, "");
}

function positiveNumber(value) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : null;
}

function isPremium(subscription = accountState.subscription) {
  if (IS_DEV) return true;
  if (!accountState.token) return false;
  if (!subscription || subscription.status !== "active" || subscription.active !== true) return false;
  if (!subscription.expires_at) return true;
  return new Date(subscription.expires_at).getTime() > Date.now();
}

function fillSelect(sel, value) {
  sel.replaceChildren();

  const empty = document.createElement("option");
  empty.value = "";
  empty.textContent = "Select currency";
  empty.selected = !value;
  sel.appendChild(empty);

  for (const currency of CURRENCIES) {
    const option = document.createElement("option");
    option.value = currency;
    option.textContent = `${currency} - ${CURRENCY_NAMES[currency] || currency}`;
    option.selected = currency === value;
    sel.appendChild(option);
  }
}

function freshnessText(lastUpdated, lastUpdatedUtc) {
  if (!lastUpdated) return "Last updated —";
  const timestamp = Number(lastUpdated);
  if (!Number.isFinite(timestamp)) return "Last updated —";
  const age = Date.now() - timestamp;
  let label;
  if (lastUpdatedUtc) {
    // Parse and display the UTC string from the API
    try {
      const d = new Date(lastUpdatedUtc);
      label = `Updated: ${d.toLocaleString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit", timeZoneName: "short" })}`;
    } catch {
      label = `Last updated ${new Date(timestamp).toLocaleString()}`;
    }
  } else {
    label = `Last updated ${new Date(timestamp).toLocaleString()}`;
  }
  if (age > STALE_AFTER_MS) return `${label} · stale`;
  return label;
}

function getCrossRate(settings, from, to) {
  if (!from || !to) return null;
  if (from === to) return 1;

  const base = settings.baseCurrency;
  const target = settings.targetCurrency;
  const manualRate = positiveNumber(settings.exchangeRate);
  const rates = settings.rates || {};

  // 1. If manual rate is defined and we are converting between base and target
  if (manualRate) {
    if (from === base && to === target) return manualRate;
    if (from === target && to === base) return 1 / manualRate;
  }

  // 2. Otherwise use fetched rates
  const fromRate = positiveNumber(rates[from]);
  const toRate = positiveNumber(rates[to]);

  if (from === base && toRate) return toRate;
  if (to === base && fromRate) return 1 / fromRate;
  if (fromRate && toRate) return toRate / fromRate;

  return null;
}

async function getSettings() {
  return storage.get([
    "baseCurrency",
    "targetCurrency",
    "exchangeRate",
    "lastUpdated",
    "lastUpdatedUtc",
    "rates",
    "rateProvider",
    "pageTooltipEnabled",
    "authToken",
    "authUser",
    "subscriptionStatus",
  ]);
}

async function apiRequest(path, options = {}) {
  const token = options.skipAuth ? null : options.token || accountState.token || (await storage.get(["authToken"])).authToken;
  const headers = {
    "content-type": "application/json",
    ...(options.headers || {}),
  };
  if (token) headers.authorization = `Bearer ${token}`;

  const res = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers,
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.error || `HTTP ${res.status}`);
  return body;
}

async function saveSubscription(subscription) {
  const normalized = subscription || { active: false, status: "inactive", plan_type: "free" };
  await storage.set({
    subscriptionStatus: normalized,
    subscriptionActive: isPremium(normalized),
    subscriptionCheckedAt: Date.now(),
  });
}

async function saveAuthResponse(data) {
  accountState = {
    token: data.token,
    user: data.user,
    subscription: data.subscription || { active: false, status: "inactive", plan_type: "free" },
  };
  await storage.set({
    authToken: accountState.token,
    authUser: accountState.user,
  });
  await saveSubscription(accountState.subscription);
  renderAccount();
}

async function clearAuth() {
  accountState = {
    token: null,
    user: null,
    subscription: { active: false, status: "inactive", plan_type: "free" },
  };
  await storage.remove([
    "authToken",
    "authUser",
    "subscriptionStatus",
    "subscriptionActive",
    "subscriptionCheckedAt",
  ]);
  renderAccount();
}

function setPremiumControls(active) {
  $("fetchBtn").disabled = !active;
  $("fetchBtn").textContent = active ? "Fetch latest rate" : "Fetch latest rate (Pro)";
  $("pageTooltipEnabled").disabled = !active;
  if (!active) $("pageTooltipEnabled").checked = false;
}

async function renderUsageBar() {
  const { conversionsUsed = 0 } = await storage.get(["conversionsUsed"]);
  const bar = $("usageBar");
  if (!bar) return;

  const premium = isPremium();
  // Hide bar for pro users
  bar.classList.toggle("hidden", premium);
  if (premium) return;

  const pct = Math.min(100, Math.round((conversionsUsed / FREE_CONVERSION_LIMIT) * 100));
  $("usageLabel").textContent = `${conversionsUsed} / ${FREE_CONVERSION_LIMIT} conversions used`;
  $("usagePct").textContent = `${pct}%`;
  const fill = $("usageFill");
  fill.style.width = `${pct}%`;
  fill.className = "usage-fill" + (pct >= 100 ? " full" : pct >= 80 ? " warn" : "");
}

function renderPlanUI() {
  const premium = isPremium();
  const planFree = $("planFree");
  const planPro  = $("planPro");
  const btn = $("upgradeBtn");

  if (!planFree || !planPro) return;

  if (premium) {
    // Highlight the pro card as active
    planPro.classList.add("active-plan");
    planFree.classList.remove("active-plan");
    // Update free card label
    const freeLabel = planFree.querySelector(".plan-cta-label");
    if (freeLabel) freeLabel.textContent = "Previous plan";
    // Update button
    if (btn) {
      btn.textContent = "✓ Lifetime Active";
      btn.disabled = true;
    }
  } else {
    planFree.classList.add("active-plan");
    planPro.classList.remove("active-plan");
    const freeLabel = planFree.querySelector(".plan-cta-label");
    if (freeLabel) freeLabel.textContent = "Current plan";
    if (btn) {
      btn.textContent = "Get Lifetime Access";
      btn.disabled = false;
    }
  }
}

function renderAccount() {
  const loggedIn = Boolean(accountState.token && accountState.user);
  const premium = isPremium();

  $("authGuest").classList.toggle("hidden", loggedIn);
  $("authUser").classList.toggle("hidden", !loggedIn);
  setPremiumControls(premium);
  renderPlanUI();
  renderUsageBar();

  if (!loggedIn) {
    $("subscriptionBadge").className = "badge free";
    setStatus("authStatus", premium ? "" : "Sign in to manage your purchase.");
    return;
  }

  $("accountEmail").textContent = accountState.user.email;
  $("subscriptionBadge").className = premium ? "badge pro" : "badge free";
  $("subscriptionBadge").textContent = premium ? "Lifetime" : "Free";
  setStatus("authStatus", premium ? "Lifetime access active." : "Upgrade for unlimited conversions.", premium ? "success" : "");
}

async function refreshAccount({ silent = false } = {}) {
  const saved = await storage.get(["authToken", "authUser", "subscriptionStatus"]);
  if (!saved.authToken) {
    accountState.token = null;
    accountState.user = null;
    accountState.subscription = { active: false, status: "inactive", plan_type: "free" };
    renderAccount();
    return false;
  }

  accountState.token = saved.authToken;
  accountState.user = saved.authUser || null;
  accountState.subscription = saved.subscriptionStatus || { active: false, status: "inactive", plan_type: "free" };
  renderAccount();

  try {
    const me = await apiRequest("/api/me");
    const subscription = await apiRequest("/api/subscription/status");
    accountState.user = me.user;
    accountState.subscription = subscription;
    await storage.set({ authUser: me.user });
    await saveSubscription(subscription);
    renderAccount();
    return isPremium(subscription);
  } catch (e) {
    if (!silent) setStatus("authStatus", e.message, "error");
    if (/token|unauthorized|invalid|expired/i.test(e.message)) await clearAuth();
    return false;
  }
}

async function verifyPremium() {
  if (!accountState.token) {
    setStatus("status", "Login and upgrade Pro to use this feature.", "error");
    return false;
  }

  const saved = await storage.get(["subscriptionStatus", "subscriptionActive", "subscriptionCheckedAt"]);
  const lastChecked = Number(saved.subscriptionCheckedAt) || 0;
  const cacheAge = Date.now() - lastChecked;
  const cacheDuration = 5 * 60 * 1000;

  if (saved.subscriptionActive === true && isPremium(saved.subscriptionStatus) && cacheAge < cacheDuration) {
    accountState.subscription = saved.subscriptionStatus;
    renderAccount();
    return true;
  }

  try {
    const subscription = await apiRequest("/api/subscription/status");
    accountState.subscription = subscription;
    await saveSubscription(subscription);
    renderAccount();
    if (!isPremium(subscription)) {
      setStatus("status", "Upgrade Pro to use this feature.", "error");
      return false;
    }
    return true;
  } catch (e) {
    if (saved.subscriptionActive === true && isPremium(saved.subscriptionStatus)) {
      accountState.subscription = saved.subscriptionStatus;
      renderAccount();
      return true;
    }
    setStatus("status", `Could not verify subscription: ${e.message}`, "error");
    return false;
  }
}

async function createCheckout() {
  if (!accountState.token) {
    setStatus("authStatus", "Sign in with Clerk before upgrading.", "error");
    openAccountPage();
    return;
  }

  setStatus("authStatus", "Creating Dodo checkout...");
  $("upgradeBtn").disabled = true;
  try {
    const checkout = await apiRequest("/api/subscription/create-checkout", { method: "POST" });
    if (typeof chrome !== "undefined" && chrome.tabs?.create) {
      chrome.tabs.create({ url: checkout.checkout_url });
    } else {
      window.open(checkout.checkout_url, "_blank", "noopener");
    }
    setStatus("authStatus", "Checkout opened. Refresh status after payment.", "success");
  } catch (e) {
    setStatus("authStatus", e.message, "error");
  } finally {
    $("upgradeBtn").disabled = isPremium();
  }
}

function openAccountPage() {
  const url = new URL(ACCOUNT_URL);
  if (typeof chrome !== "undefined" && chrome.runtime?.id) {
    url.searchParams.set("extensionId", chrome.runtime.id);
  }

  if (typeof chrome !== "undefined" && chrome.tabs?.create) {
    chrome.tabs.create({ url: url.toString() });
  } else {
    window.open(url.toString(), "_blank", "noopener");
  }
}

async function autoFetchIfStale() {
  const s = await getSettings();
  const base = s.baseCurrency;
  const target = s.targetCurrency;
  if (!base || !target) return;

  const lastUpdated = Number(s.lastUpdated) || 0;
  const age = Date.now() - lastUpdated;
  const hasRate = positiveNumber(s.exchangeRate);
  const isStale = age > STALE_AFTER_MS;

  // Rate is fresh — just update the ticker and bail
  if (hasRate && !isStale) {
    updateLiveTicker(s);
    return;
  }

  // Need a fresh fetch — only if user can use live rates
  const canFetch = IS_DEV || isPremium();
  if (!canFetch) {
    // Still show whatever cached data we have
    if (hasRate) updateLiveTicker(s);
    return;
  }

  // Show loading state in ticker
  const ticker = $("liveTicker");
  if (ticker) {
    ticker.classList.remove("hidden");
    $("liveTickerRate").textContent = "Fetching rate…";
    $("liveTickerBadge").textContent = "…";
    $("liveTickerBadge").className = "live-badge loading";
  }

  await fetchLatest({ silent: true });
}

function updateLiveTicker(s) {
  const ticker = $("liveTicker");
  if (!ticker) return;

  // Prefer settings object, fall back to DOM values
  const base = (s && s.baseCurrency) || $("baseCurrency").value;
  const target = (s && s.targetCurrency) || $("targetCurrency").value;

  // Try to find any usable rate
  let rate = null;
  if (s) {
    // 1. Direct stored exchange rate (most reliable)
    rate = positiveNumber(s.exchangeRate);
    // 2. From full rates map
    if (!rate && s.rates && s.baseCurrency && s.targetCurrency) {
      rate = positiveNumber(s.rates[s.targetCurrency]);
    }
  } else {
    rate = positiveNumber($("exchangeRate").value);
  }

  if (!base || !target || !rate) {
    ticker.classList.add("hidden");
    return;
  }

  ticker.classList.remove("hidden");
  $("liveTickerRate").textContent = `1 ${base} = ${formatRate(rate, target)} ${target}`;

  const lastUpdated = s ? (Number(s.lastUpdated) || 0) : 0;
  const age = Date.now() - lastUpdated;
  const isStale = lastUpdated > 0 && age > STALE_AFTER_MS;
  const isLive  = lastUpdated > 0 && !isStale;
  const badge = $("liveTickerBadge");

  if (isLive) {
    badge.textContent = "LIVE";
    badge.className = "live-badge live";
  } else if (isStale) {
    badge.textContent = "STALE";
    badge.className = "live-badge stale";
  } else {
    badge.textContent = "MANUAL";
    badge.className = "live-badge manual";
  }
}

async function load() {
  let s = {};
  try {
    s = await getSettings();
  } catch {
    setStatus("status", "Could not load saved settings.", "error");
  }
  const base = s.baseCurrency || "";
  const target = s.targetCurrency || "";
  const rate = getCrossRate(s, base, target) || Number(s.exchangeRate) || "";

  fillSelect($("baseCurrency"), base);
  fillSelect($("targetCurrency"), target);
  $("exchangeRate").value = rate;
  $("lastUpdated").textContent = freshnessText(s.lastUpdated, s.lastUpdatedUtc);
  $("calcFrom").textContent = base || "Base";
  $("pageTooltipEnabled").checked = s.pageTooltipEnabled !== false && isPremium(s.subscriptionStatus);
  updatePreview();
  updateLiveTicker(s);
  await refreshAccount({ silent: true });
  // After account check, attempt silent auto-fetch if rate is stale
  autoFetchIfStale();
}

function updatePreview() {
  const base = $("baseCurrency").value;
  const target = $("targetCurrency").value;
  const rate = positiveNumber($("exchangeRate").value) || 0;
  const amountValue = $("calcAmount").value;
  const amount = Number(amountValue);
  const hasAmount = amountValue !== "" && Number.isFinite(amount);
  const canConvert = base && target && rate > 0 && hasAmount;

  $("calcFrom").textContent = base || "Base";

  // Update rate info panel
  const rateInfoPanel = $("rateInfoPanel");
  const rateInfoText = $("rateInfoText");
  const rateUpdatedText = $("rateUpdatedText");

  if (!base || !target) {
    $("previewFrom").textContent = "Choose currencies";
    $("previewTo").textContent = "No conversion";
    $("previewRate").textContent = "Base and target currency are required";
    $("calcResult").textContent = "Choose currencies";
    if (rateInfoPanel) rateInfoPanel.classList.add("hidden");
    return;
  }

  if (!rate) {
    $("previewFrom").textContent = hasAmount ? format(amount, base) : "Enter amount";
    $("previewTo").textContent = "Enter rate";
    $("previewRate").textContent = `Enter or fetch the rate for 1 ${base} to ${target}`;
    $("calcResult").textContent = "Enter rate";
    if (rateInfoPanel) rateInfoPanel.classList.add("hidden");
    return;
  }

  $("previewFrom").textContent = hasAmount ? format(amount, base) : "Enter amount";
  $("previewTo").textContent = canConvert ? format(multiplySafe(amount, rate), target) : "Enter amount";
  $("previewRate").textContent = `1 ${base} = ${formatRate(rate, target)} ${target}`;
  $("calcResult").textContent = canConvert ? format(multiplySafe(amount, rate), target) : "Enter amount";

  // Show rate info panel
  if (rateInfoPanel) {
    rateInfoPanel.classList.remove("hidden");
    if (rateInfoText) rateInfoText.textContent = `1 ${base} = ${formatRate(rate, target)} ${target}`;
  }
}

async function save({ manualRateChanged = false } = {}) {
  const base = $("baseCurrency").value;
  const target = $("targetCurrency").value;
  const rateValue = $("exchangeRate").value;
  const current = await getSettings();
  const baseChanged = base !== (current.baseCurrency || "");
  const targetChanged = target !== (current.targetCurrency || "");
  const updates = {};
  const removals = [];

  if (base) updates.baseCurrency = base;
  else removals.push("baseCurrency");

  if (target) updates.targetCurrency = target;
  else removals.push("targetCurrency");

  const isIdentityPair = base && target && base === target;
  const hasValidRates = !baseChanged && current.rates && Object.keys(current.rates).length > 0;
  const canUseCachedRates = !manualRateChanged && hasValidRates;
  const cachedRate = isIdentityPair ? 1 : canUseCachedRates ? positiveNumber((current.rates || {})[target]) : null;
  const manualRate = positiveNumber(rateValue);

  if (cachedRate) {
    updates.exchangeRate = cachedRate;
    $("exchangeRate").value = cachedRate;
  } else if (manualRateChanged && base && target && manualRate) {
    updates.exchangeRate = manualRate;
  } else if (!manualRateChanged && !baseChanged && !targetChanged && base && target && manualRate) {
    updates.exchangeRate = manualRate;
  } else {
    removals.push("exchangeRate");
    $("exchangeRate").value = "";
  }

  if (manualRateChanged || baseChanged || !base || isIdentityPair) {
    removals.push("lastUpdated", "rates", "rateProvider");
    $("lastUpdated").textContent = freshnessText(null);
  } else {
    $("lastUpdated").textContent = freshnessText(current.lastUpdated);
  }

  await storage.remove(removals);
  if (Object.keys(updates).length) await storage.set(updates);
  updatePreview();
}

async function fetchLatest({ silent = false } = {}) {
  const base = $("baseCurrency").value;
  const target = $("targetCurrency").value;
  if (!silent) setStatus("status", "");
  if (!base || !target) {
    if (!silent) setStatus("status", "Choose base and target currencies first.", "error");
    return;
  }

  // In dev mode bypass subscription check; otherwise verify premium
  if (!IS_DEV && !(await verifyPremium())) return;

  if (base === target) {
    const lastUpdated = Date.now();
    await storage.set({
      baseCurrency: base,
      targetCurrency: target,
      exchangeRate: 1,
      lastUpdated,
      lastUpdatedUtc: new Date(lastUpdated).toUTCString(),
      rates: { [base]: 1 },
      rateProvider: "Identity rate",
    });
    $("exchangeRate").value = 1;
    $("lastUpdated").textContent = freshnessText(lastUpdated, new Date(lastUpdated).toUTCString());
    if (!silent) setStatus("status", `Updated · 1 ${base} = 1 ${target}`, "success");
    updatePreview();
    updateRateTimestamp();
    return;
  }

  if (!silent) setStatus("status", "Fetching latest rate...");
  const refreshBtn = $("refreshRateBtn");
  $("fetchBtn").disabled = true;
  if (refreshBtn) { refreshBtn.disabled = true; refreshBtn.textContent = "⟳"; refreshBtn.classList.add("spinning"); }
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), API_TIMEOUT_MS);
  try {
    const res = await fetch(`https://open.er-api.com/v6/latest/${encodeURIComponent(base)}`, {
      signal: controller.signal,
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    if (data?.result !== "success") {
      throw new Error(data?.["error-type"] || "API error");
    }

    const rates = data.rates || {};
    const rate = positiveNumber(rates[target]);
    if (!rate) throw new Error("Rate not in response");

    const lastUpdated = data.time_last_update_unix
      ? Number(data.time_last_update_unix) * 1000
      : Date.now();
    const lastUpdatedUtc = data.time_last_update_utc || new Date(lastUpdated).toUTCString();

    await storage.set({
      baseCurrency: base,
      targetCurrency: target,
      exchangeRate: rate,
      lastUpdated,
      lastUpdatedUtc,
      rates,
      rateProvider: "ExchangeRate-API",
    });

    $("exchangeRate").value = rate;
    $("lastUpdated").textContent = freshnessText(lastUpdated, lastUpdatedUtc);
    if (!silent) setStatus("status", `Updated from ExchangeRate-API · 1 ${base} = ${rate} ${target}`, "success");
    updatePreview();
    updateRateTimestamp(lastUpdatedUtc, lastUpdated);
    updateLiveTicker({ baseCurrency: base, targetCurrency: target, exchangeRate: rate, rates, lastUpdated, lastUpdatedUtc });
  } catch (e) {
    const message = e.name === "AbortError" ? "Request timed out" : e.message;
    if (!silent) setStatus("status", `Failed: ${message}. Enter a rate manually.`, "error");
  } finally {
    clearTimeout(timeout);
    $("fetchBtn").disabled = !isPremium();
    if (refreshBtn) { refreshBtn.disabled = false; refreshBtn.textContent = "↻"; refreshBtn.classList.remove("spinning"); }
  }
}

async function updateRateTimestamp(utcStr, ts) {
  if (!utcStr && !ts) {
    const s = await getSettings();
    utcStr = s.lastUpdatedUtc;
    ts = s.lastUpdated;
  }
  const el = $("rateUpdatedText");
  if (el) el.textContent = freshnessText(ts, utcStr);
  // Also refresh the live ticker badge freshness
  const s = await getSettings();
  updateLiveTicker(s);
}

async function refreshRate() {
  // Clear cached rates then re-fetch
  await storage.remove(["lastUpdated", "lastUpdatedUtc", "rates", "rateProvider", "exchangeRate"]);
  $("exchangeRate").value = "";
  await fetchLatest();
}

async function savePageTooltipEnabled() {
  if (!(await verifyPremium())) {
    $("pageTooltipEnabled").checked = false;
    await storage.set({ pageTooltipEnabled: false });
    return;
  }
  await storage.set({
    pageTooltipEnabled: $("pageTooltipEnabled").checked,
  });
}

async function reset() {
  await storage.remove([
    "baseCurrency",
    "targetCurrency",
    "exchangeRate",
    "lastUpdated",
    "lastUpdatedUtc",
    "rates",
    "rateProvider",
  ]);
  const ticker = $("liveTicker");
  if (ticker) ticker.classList.add("hidden");
  setStatus("status", "Cleared saved values.");
  await load();
}

function init() {
  renderAccount();
  load().then(() => updateRateTimestamp());
  ["baseCurrency", "targetCurrency"].forEach((id) => {
    $(id).addEventListener("change", save);
  });
  $("exchangeRate").addEventListener("input", () => {
    updatePreview();
    clearTimeout(saveTimer);
    saveTimer = setTimeout(async () => {
      await save({ manualRateChanged: true });
      const s = await getSettings();
      updateLiveTicker(s);
    }, 350);
  });
  $("exchangeRate").addEventListener("change", async () => {
    await save({ manualRateChanged: true });
    const s = await getSettings();
    updateLiveTicker(s);
  });
  $("calcAmount").addEventListener("input", updatePreview);
  $("pageTooltipEnabled").addEventListener("change", savePageTooltipEnabled);
  $("fetchBtn").addEventListener("click", fetchLatest);
  $("resetBtn").addEventListener("click", reset);
  $("signInBtn").addEventListener("click", openAccountPage);
  $("upgradeBtn").addEventListener("click", createCheckout);
  $("refreshSubBtn").addEventListener("click", () => refreshAccount());
  $("logoutBtn").addEventListener("click", clearAuth);
  $("accountPageBtn").addEventListener("click", openAccountPage);
  const refreshRateBtn = $("refreshRateBtn");
  if (refreshRateBtn) refreshRateBtn.addEventListener("click", refreshRate);
  if (typeof chrome !== "undefined" && chrome.storage?.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && (changes.authToken || changes.authUser || changes.subscriptionStatus)) {
        refreshAccount({ silent: true });
      }
    });
  }
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}
