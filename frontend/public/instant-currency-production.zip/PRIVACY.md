# Privacy Policy

Effective date: May 21, 2026

Instant Currency is designed to work locally in the browser.

## Data Stored Locally

The extension stores these settings in Chrome local storage:

- Clerk session token
- Signed-in user email and Clerk user ID returned by the account page/backend
- Subscription status returned by the backend
- Base currency
- Target currency
- Manual exchange rate, if entered
- Latest fetched exchange rates
- Last updated timestamp
- Page tooltip enabled/disabled preference

This data stays on the user's device unless the user syncs browser extension data through Chrome or another browser feature outside this extension's control.

## Data Sent to Third Parties

When a user signs in, Clerk handles authentication on the separate account page. The account page sends a Clerk session token, user ID, email, and subscription status back to the extension. The extension sends the Clerk token to the backend when checking account and subscription status or creating a checkout session.

When a logged-in user clicks Upgrade Pro, the extension asks the backend to create a Dodo Payments checkout session. The backend contacts Dodo Payments. The extension opens the checkout URL returned by the backend.

When a Pro user clicks Fetch latest rate, the extension requests rates from:

`https://open.er-api.com/v6/latest/{baseCurrency}`

That request includes the chosen base currency code in the URL. The extension does not send selected webpage text, converted amounts, target currency preferences, browsing history, page content, names, or analytics events to ExchangeRate-API.

## Webpage Access

The extension runs a content script on `http` and `https` webpages so it can detect currency amounts selected by the user and show a conversion tooltip. Selected text is processed locally in the browser. It is not transmitted by the extension.

Users can disable the page tooltip from the extension popup.

## Data Collection

Instant Currency does not collect, sell, rent, or share user data. It does not use analytics, advertising SDKs, tracking pixels, or remote logging.

The backend stores Clerk user IDs, optional email addresses, and subscription status so Pro access can be verified server-side. Dodo Payments handles payment details on its hosted checkout page; payment card data is not handled by the extension.

## Contact

Use the publisher support contact listed on the Chrome Web Store page for this extension.
